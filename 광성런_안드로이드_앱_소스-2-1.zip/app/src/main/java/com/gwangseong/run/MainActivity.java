package com.gwangseong.run;

import android.Manifest;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;
import java.util.Locale;

public class MainActivity extends android.app.Activity {
    private LinearLayout authPanel,loginPanel,signupPanel,appPanel;
    private EditText loginPhone,loginPassword,signupName,signupPhone,signupPassword,signupPassword2;
    private TextView authStatus,status,memberInfo,distance,stepsView,time,coins,pointsBalance;
    private Button loginTab,signupTab,loginButton,signupButton,logoutButton,startButton,stopButton,submitButton,refreshButton;
    private android.content.SharedPreferences prefs; private int steps; private long seconds; private boolean approved=false;

    private final BroadcastReceiver updates=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){steps=i.getIntExtra("steps",0);seconds=i.getLongExtra("seconds",0);render();}};

    @Override protected void onCreate(Bundle state){super.onCreate(state);setContentView(R.layout.activity_main);
        prefs=getSharedPreferences("run",MODE_PRIVATE);
        bind();
        steps=prefs.getInt("lastSteps",0);seconds=prefs.getLong("lastSeconds",0);render();

        loginTab.setOnClickListener(v->showLogin()); signupTab.setOnClickListener(v->showSignup());
        loginButton.setOnClickListener(v->login()); signupButton.setOnClickListener(v->signup()); logoutButton.setOnClickListener(v->logout());
        refreshButton.setOnClickListener(v->loadProfile(true));
        startButton.setOnClickListener(v->startRun()); stopButton.setOnClickListener(v->stopRun()); submitButton.setOnClickListener(v->submit());

        boolean running=prefs.getBoolean("running",false); startButton.setEnabled(!running); stopButton.setEnabled(running); submitButton.setEnabled(!running&&steps>0);
        requestPermissionsIfNeeded();
        if(!prefs.getString("accessToken","").isEmpty()) loadProfile(true); else showAuth();
    }

    private void bind(){
        authPanel=findViewById(R.id.authPanel);loginPanel=findViewById(R.id.loginPanel);signupPanel=findViewById(R.id.signupPanel);appPanel=findViewById(R.id.appPanel);
        loginPhone=findViewById(R.id.loginPhone);loginPassword=findViewById(R.id.loginPassword);signupName=findViewById(R.id.signupName);signupPhone=findViewById(R.id.signupPhone);signupPassword=findViewById(R.id.signupPassword);signupPassword2=findViewById(R.id.signupPassword2);
        authStatus=findViewById(R.id.authStatus);status=findViewById(R.id.status);memberInfo=findViewById(R.id.memberInfo);distance=findViewById(R.id.distance);stepsView=findViewById(R.id.steps);time=findViewById(R.id.time);coins=findViewById(R.id.coins);pointsBalance=findViewById(R.id.pointsBalance);
        loginTab=findViewById(R.id.loginTab);signupTab=findViewById(R.id.signupTab);loginButton=findViewById(R.id.loginButton);signupButton=findViewById(R.id.signupButton);logoutButton=findViewById(R.id.logoutButton);startButton=findViewById(R.id.startButton);stopButton=findViewById(R.id.stopButton);submitButton=findViewById(R.id.submitButton);refreshButton=findViewById(R.id.refreshButton);
        loginPhone.setText(prefs.getString("phone",""));
    }

    @Override protected void onStart(){super.onStart();IntentFilter filter=new IntentFilter(RunService.ACTION_UPDATE);if(Build.VERSION.SDK_INT>=33)registerReceiver(updates,filter,RECEIVER_NOT_EXPORTED);else registerReceiver(updates,filter);}
    @Override protected void onStop(){try{unregisterReceiver(updates);}catch(Exception ignored){}super.onStop();}

    private void showAuth(){authPanel.setVisibility(View.VISIBLE);appPanel.setVisibility(View.GONE);showLogin();}
    private void showLogin(){loginPanel.setVisibility(View.VISIBLE);signupPanel.setVisibility(View.GONE);authStatus.setText("광성런 계정으로 로그인해주세요.");}
    private void showSignup(){loginPanel.setVisibility(View.GONE);signupPanel.setVisibility(View.VISIBLE);authStatus.setText("센터 회원 정보를 입력해 가입해주세요.");}
    private void showApp(){authPanel.setVisibility(View.GONE);appPanel.setVisibility(View.VISIBLE);}

    private void signup(){
        String name=signupName.getText().toString().trim(),phone=signupPhone.getText().toString().trim(),pw=signupPassword.getText().toString(),pw2=signupPassword2.getText().toString();
        if(name.isEmpty()||phone.length()<10||pw.length()<6){authStatus.setText("이름, 휴대폰번호, 6자리 이상 비밀번호를 확인해주세요.");return;}
        if(!pw.equals(pw2)){authStatus.setText("비밀번호가 서로 달라요.");return;}
        signupButton.setEnabled(false);authStatus.setText("회원가입 중…");
        ApiClient.signup(name,phone,pw,(ok,msg,data)->runOnUiThread(()->{signupButton.setEnabled(true);authStatus.setText(msg);if(ok){String no=data.optString("memberNo","");Toast.makeText(this,"회원번호 "+no+" · 가입 완료",Toast.LENGTH_LONG).show();loginPhone.setText(phone);loginPassword.setText("");showLogin();authStatus.setText("가입 완료 · 회원번호 "+no+"\n이제 바로 로그인해서 이용할 수 있어요.");}}));
    }

    private void login(){
        String phone=loginPhone.getText().toString().trim(),pw=loginPassword.getText().toString();if(phone.length()<10||pw.length()<6){authStatus.setText("휴대폰번호와 비밀번호를 확인해주세요.");return;}
        loginButton.setEnabled(false);authStatus.setText("로그인 중…");
        ApiClient.login(phone,pw,(ok,msg,data)->runOnUiThread(()->{loginButton.setEnabled(true);if(ok){prefs.edit().putString("accessToken",data.optString("access_token","")).putString("refreshToken",data.optString("refresh_token","")).putString("phone",phone).apply();loginPassword.setText("");loadProfile(false);}else authStatus.setText(msg);}));
    }

    private void loadProfile(boolean allowRefresh){
        String token=prefs.getString("accessToken","");if(token.isEmpty()){showAuth();return;}
        if(appPanel.getVisibility()==View.VISIBLE) status.setText("회원정보 확인 중…"); else authStatus.setText("회원정보 확인 중…");
        ApiClient.profile(token,(ok,msg,data)->runOnUiThread(()->{
            if(ok){applyProfile(data);return;}
            if(allowRefresh&&!prefs.getString("refreshToken","").isEmpty()) refreshSession(); else {prefs.edit().remove("accessToken").remove("refreshToken").apply();showAuth();authStatus.setText("로그인이 만료됐어요. 다시 로그인해주세요.");}
        }));
    }

    private void refreshSession(){
        ApiClient.refresh(prefs.getString("refreshToken",""),(ok,msg,data)->runOnUiThread(()->{if(ok){prefs.edit().putString("accessToken",data.optString("access_token","")).putString("refreshToken",data.optString("refresh_token",prefs.getString("refreshToken",""))).apply();loadProfile(false);}else{logout();authStatus.setText("로그인이 만료됐어요. 다시 로그인해주세요.");}}));
    }

    private void applyProfile(JSONObject data){
        showApp();String name=data.optString("name","회원"),memberNo=data.optString("memberNo",""),state=data.optString("accountStatus","pending");int balance=data.optInt("pointsBalance",0);
        prefs.edit().putString("name",name).putString("memberNo",memberNo).apply();memberInfo.setText(name+"님 · "+memberNo);pointsBalance.setText(String.format(Locale.KOREA,"%,d P",balance));
        approved="approved".equals(state);
        if(approved) status.setText("로그인 완료 · 바로 러닝을 시작할 수 있어요.");
        else if("suspended".equals(state)) status.setText("현재 이용이 중지된 계정이에요. 센터에 문의해주세요.");
        else status.setText("계정 상태를 확인해주세요.");
        boolean running=prefs.getBoolean("running",false);startButton.setEnabled(approved&&!running);stopButton.setEnabled(approved&&running);submitButton.setEnabled(approved&&!running&&steps>0);
    }

    private void logout(){prefs.edit().remove("accessToken").remove("refreshToken").remove("memberNo").remove("name").apply();approved=false;showAuth();authStatus.setText("로그아웃했어요.");}

    private void startRun(){if(!approved){status.setText("현재 이용할 수 없는 계정이에요. 센터에 문의해주세요.");return;}if(Build.VERSION.SDK_INT>=29&&checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION)!=PackageManager.PERMISSION_GRANTED){requestPermissionsIfNeeded();status.setText("신체활동 권한을 허용해주세요.");return;}steps=0;seconds=0;prefs.edit().putInt("lastSteps",0).putLong("lastSeconds",0).apply();Intent intent=new Intent(this,RunService.class).setAction(RunService.ACTION_START);startForegroundService(intent);startButton.setEnabled(false);stopButton.setEnabled(true);submitButton.setEnabled(false);status.setText("측정 중 · 화면을 꺼도 계속 측정돼요.");render();}
    private void stopRun(){startService(new Intent(this,RunService.class).setAction(RunService.ACTION_STOP));steps=prefs.getInt("steps",steps);long started=prefs.getLong("startedAt",System.currentTimeMillis());seconds=Math.max(seconds,(System.currentTimeMillis()-started)/1000);prefs.edit().putInt("lastSteps",steps).putLong("lastSeconds",seconds).apply();startButton.setEnabled(approved);stopButton.setEnabled(false);submitButton.setEnabled(approved&&steps>0);status.setText("측정 완료 · 관리자 승인 요청을 눌러주세요.");render();}
    private void submit(){if(!approved){status.setText("현재 이용할 수 없는 계정이에요. 센터에 문의해주세요.");return;}if(steps<1||seconds<10){status.setText("10초 이상 측정한 기록만 전송할 수 있어요.");return;}submitButton.setEnabled(false);status.setText("관리자에게 전송 중…");double km=steps*0.0007;ApiClient.submit(prefs.getString("accessToken",""),steps,seconds,km,(ok,msg,data)->runOnUiThread(()->{status.setText(msg);if(ok){steps=0;seconds=0;prefs.edit().putInt("lastSteps",0).putLong("lastSeconds",0).apply();render();loadProfile(true);}else submitButton.setEnabled(true);}));}
    private void render(){double km=steps*0.0007;distance.setText(String.format(Locale.KOREA,"%.2f km",km));stepsView.setText(String.format(Locale.KOREA,"%,d 걸음",steps));time.setText(String.format(Locale.KOREA,"%02d:%02d",seconds/60,seconds%60));coins.setText(((int)Math.floor(km*10))+" P");}
    private void requestPermissionsIfNeeded(){java.util.ArrayList<String> list=new java.util.ArrayList<>();if(Build.VERSION.SDK_INT>=29&&checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION)!=PackageManager.PERMISSION_GRANTED)list.add(Manifest.permission.ACTIVITY_RECOGNITION);if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)list.add(Manifest.permission.POST_NOTIFICATIONS);if(!list.isEmpty())requestPermissions(list.toArray(new String[0]),10);}
}
