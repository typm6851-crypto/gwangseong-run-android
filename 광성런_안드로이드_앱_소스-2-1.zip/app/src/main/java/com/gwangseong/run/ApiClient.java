package com.gwangseong.run;

import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

public final class ApiClient {
    private static final String BASE="https://phwxdwtszdazqrjyktph.supabase.co";
    private static final String API_KEY="sb_publishable_Ln3Ah58nCB9xZRhV3Ca0Wg_2_ugk9SW";
    private static final String FN=BASE+"/functions/v1/gwangseong-app";

    public interface Callback { void done(boolean ok, String message, JSONObject data); }

    public static void signup(String name,String phone,String password,Callback callback){
        JSONObject body=new JSONObject(); try{body.put("name",name);body.put("phone",phone);body.put("password",password);}catch(Exception ignored){}
        postJson(FN+"/signup",body,null,callback);
    }

    public static void login(String phone,String password,Callback callback){
        JSONObject body=new JSONObject(); try{body.put("phone",normalizePhone(phone));body.put("password",password);}catch(Exception ignored){}
        postJson(BASE+"/auth/v1/token?grant_type=password",body,null,(ok,msg,data)->{
            if(ok && data.has("access_token")) callback.done(true,"로그인했어요.",data);
            else callback.done(false,translateAuth(data.optString("error_description",data.optString("msg",msg))),data);
        });
    }

    public static void refresh(String refreshToken,Callback callback){
        JSONObject body=new JSONObject(); try{body.put("refresh_token",refreshToken);}catch(Exception ignored){}
        postJson(BASE+"/auth/v1/token?grant_type=refresh_token",body,null,(ok,msg,data)->{
            if(ok && data.has("access_token")) callback.done(true,"갱신 완료",data);
            else callback.done(false,"다시 로그인해주세요.",data);
        });
    }

    public static void profile(String accessToken,Callback callback){
        postJson(FN+"/profile",new JSONObject(),accessToken,callback);
    }

    public static void submit(String accessToken,int steps,long seconds,double km,Callback callback){
        JSONObject body=new JSONObject(); try{body.put("steps",steps);body.put("seconds",seconds);body.put("distanceKm",km);}catch(Exception ignored){}
        postJson(FN+"/run",body,accessToken,callback);
    }

    private static String normalizePhone(String v){
        String d=v==null?"":v.replaceAll("\\D","");
        if(d.startsWith("82")) return "+"+d;
        if(d.startsWith("0")) return "+82"+d.substring(1);
        return d.startsWith("+")?d:"+82"+d;
    }

    private static String translateAuth(String msg){
        String m=msg==null?"":msg.toLowerCase();
        if(m.contains("invalid login")||m.contains("invalid credentials")) return "휴대폰번호 또는 비밀번호가 맞지 않아요.";
        if(m.contains("email not confirmed")||m.contains("phone not confirmed")) return "휴대폰 인증이 완료되지 않았어요.";
        return msg==null||msg.isEmpty()?"로그인에 실패했어요.":msg;
    }

    private static void postJson(String url,JSONObject body,String accessToken,Callback callback){
        new Thread(()->{
            HttpURLConnection connection=null;
            try{
                connection=(HttpURLConnection)new URL(url).openConnection();
                connection.setRequestMethod("POST");connection.setConnectTimeout(12000);connection.setReadTimeout(12000);connection.setDoOutput(true);
                connection.setRequestProperty("Content-Type","application/json; charset=utf-8");
                connection.setRequestProperty("apikey",API_KEY);
                if(accessToken!=null&&!accessToken.isEmpty()) connection.setRequestProperty("Authorization","Bearer "+accessToken);
                byte[] bytes=body.toString().getBytes(StandardCharsets.UTF_8);
                try(OutputStream out=connection.getOutputStream()){out.write(bytes);}
                int status=connection.getResponseCode(); InputStream input=status<400?connection.getInputStream():connection.getErrorStream();
                StringBuilder text=new StringBuilder();
                if(input!=null) try(BufferedReader reader=new BufferedReader(new InputStreamReader(input,StandardCharsets.UTF_8))){String line;while((line=reader.readLine())!=null)text.append(line);}
                JSONObject result=text.length()>0?new JSONObject(text.toString()):new JSONObject();
                boolean ok=status>=200&&status<300&&(result.has("ok")?result.optBoolean("ok"):true);
                String message=result.optString("message",status>=200&&status<300?"처리했어요.":"요청을 처리하지 못했어요.");
                callback.done(ok,message,result);
            }catch(Exception error){callback.done(false,"인터넷 연결을 확인해주세요.",new JSONObject());}
            finally{if(connection!=null)connection.disconnect();}
        }).start();
    }
}
