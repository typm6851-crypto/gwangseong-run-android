package com.gwangseong.run;

import android.Manifest;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.view.View;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends android.app.Activity {
    private EditText memberNo,phoneLast4; private TextView status,distance,stepsView,time,coins;
    private Button connectButton,startButton,stopButton,submitButton;
    private android.content.SharedPreferences prefs; private int steps; private long seconds;

    private final BroadcastReceiver updates=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){steps=i.getIntExtra("steps",0);seconds=i.getLongExtra("seconds",0);render();}};

    @Override protected void onCreate(Bundle state){super.onCreate(state);setContentView(R.layout.activity_main);
        prefs=getSharedPreferences("run",MODE_PRIVATE);
        memberNo=findViewById(R.id.memberNo);phoneLast4=findViewById(R.id.phoneLast4);status=findViewById(R.id.status);distance=findViewById(R.id.distance);stepsView=findViewById(R.id.steps);time=findViewById(R.id.time);coins=findViewById(R.id.coins);
        connectButton=findViewById(R.id.connectButton);startButton=findViewById(R.id.startButton);stopButton=findViewById(R.id.stopButton);submitButton=findViewById(R.id.submitButton);
        memberNo.setText(prefs.getString("memberNo",""));phoneLast4.setText(prefs.getString("phoneLast4",""));
        if(!memberNo.getText().toString().isEmpty())status.setText(prefs.getString("name","회원")+"님 · 연결됨");
        steps=prefs.getInt("lastSteps",0);seconds=prefs.getLong("lastSeconds",0);render();
        connectButton.setOnClickListener(v->connect());startButton.setOnClickListener(v->startRun());stopButton.setOnClickListener(v->stopRun());submitButton.setOnClickListener(v->submit());
        boolean running=prefs.getBoolean("running",false);startButton.setEnabled(!running);stopButton.setEnabled(running);submitButton.setEnabled(!running&&steps>0);
        requestPermissionsIfNeeded();
    }
    @Override protected void onStart(){super.onStart();IntentFilter filter=new IntentFilter(RunService.ACTION_UPDATE);if(Build.VERSION.SDK_INT>=33)registerReceiver(updates,filter,RECEIVER_NOT_EXPORTED);else registerReceiver(updates,filter);}
    @Override protected void onStop(){try{unregisterReceiver(updates);}catch(Exception ignored){}super.onStop();}

    private void connect(){String no=memberNo.getText().toString().trim().toUpperCase(Locale.KOREA);String phone=phoneLast4.getText().toString().trim();if(no.isEmpty()||phone.length()!=4){status.setText("회원번호와 휴대폰 뒷자리 4개를 입력해주세요.");return;}connectButton.setEnabled(false);status.setText("회원정보 확인 중…");ApiClient.verify(no,phone,(ok,msg,data)->runOnUiThread(()->{connectButton.setEnabled(true);if(ok){String name=data.optString("name","회원");prefs.edit().putString("memberNo",no).putString("phoneLast4",phone).putString("name",name).apply();status.setText(name+"님 · 연결 완료");}else status.setText(msg);}));}
    private boolean connected(){return !prefs.getString("memberNo","").isEmpty()&&!prefs.getString("phoneLast4","").isEmpty();}
    private void startRun(){if(!connected()){status.setText("먼저 회원 연결을 완료해주세요.");return;}if(Build.VERSION.SDK_INT>=29&&checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION)!=PackageManager.PERMISSION_GRANTED){requestPermissionsIfNeeded();status.setText("신체활동 권한을 허용해주세요.");return;}steps=0;seconds=0;prefs.edit().putInt("lastSteps",0).putLong("lastSeconds",0).apply();Intent intent=new Intent(this,RunService.class).setAction(RunService.ACTION_START);startForegroundService(intent);startButton.setEnabled(false);stopButton.setEnabled(true);submitButton.setEnabled(false);status.setText("측정 중 · 화면을 꺼도 계속 측정돼요.");render();}
    private void stopRun(){startService(new Intent(this,RunService.class).setAction(RunService.ACTION_STOP));steps=prefs.getInt("steps",steps);long started=prefs.getLong("startedAt",System.currentTimeMillis());seconds=Math.max(seconds,(System.currentTimeMillis()-started)/1000);prefs.edit().putInt("lastSteps",steps).putLong("lastSeconds",seconds).apply();startButton.setEnabled(true);stopButton.setEnabled(false);submitButton.setEnabled(steps>0);status.setText("측정 완료 · 승인 요청을 눌러주세요.");render();}
    private void submit(){if(steps<1||seconds<10){status.setText("10초 이상 측정한 기록만 전송할 수 있어요.");return;}submitButton.setEnabled(false);status.setText("관리자에게 전송 중…");double km=steps*0.0007;ApiClient.submit(prefs.getString("memberNo",""),prefs.getString("phoneLast4",""),steps,seconds,km,(ok,msg,data)->runOnUiThread(()->{status.setText(msg);if(ok){steps=0;seconds=0;prefs.edit().putInt("lastSteps",0).putLong("lastSeconds",0).apply();render();}else submitButton.setEnabled(true);}));}
    private void render(){double km=steps*0.0007;distance.setText(String.format(Locale.KOREA,"%.2f km",km));stepsView.setText(String.format(Locale.KOREA,"%,d 걸음",steps));time.setText(String.format(Locale.KOREA,"%02d:%02d",seconds/60,seconds%60));coins.setText(((int)Math.floor(km*10))+" C");}
    private void requestPermissionsIfNeeded(){java.util.ArrayList<String> list=new java.util.ArrayList<>();if(Build.VERSION.SDK_INT>=29&&checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION)!=PackageManager.PERMISSION_GRANTED)list.add(Manifest.permission.ACTIVITY_RECOGNITION);if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)list.add(Manifest.permission.POST_NOTIFICATIONS);if(!list.isEmpty())requestPermissions(list.toArray(new String[0]),10);}
}
